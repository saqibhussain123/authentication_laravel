<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- session -->
     <!-- use to manage information across different pages -->
      <!-- start the session and get the data -->
      <?php

session_start();
$_SESSION['username']='harry';
$_SESSION['email']='herry@gmail.com';
echo 'we have saved your session';
echo'<br>';
// echo 'My name is '.$_SESSION['username'];
// so i have checked here that if my username is set
if (isset($_SESSION['username'])) {
    echo 'welcome'.$_SESSION['username'];
    echo '  <br> email is'.$_SESSION['email'];

}else {
    'please login to continue';
}
// use in logout functionality
// session_destroy();
// session_unset();

?>
</body>
</html>