<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#"method="post">

    name    <input type="text" name="name">
      email  <input type="email" name="email">
     password   <input type="password" name="password">
        <input type="submit" value="submit">
        </form>
<?php
 if (isset($_POST['submit'])) {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];


    // echo`my name is ${$name} `;

    if ($name==$name&& $email==$email) {
        header('location: practice.php');
    }
 }




?>
</body>
</html>