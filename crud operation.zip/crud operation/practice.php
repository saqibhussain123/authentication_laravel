<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method="post">
        Name <input type="text" placeholder="enter your name here"name='name'>
        email <input type="email" placeholder="enter your email here" name="email">
        password <input type="password" placeholder="enter your password here" name="password">
        <input type="submit" value="submit" name="submit">
    </form>
    <?php
  if (isset($_POST['submit'])) {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    
    echo 'my name is'.$name."<br>";
    echo 'my email is'.$email."<br>";
echo 'my   password '.$password."<br>";
echo "<br>";

// if ($name==$name&& $email==$email&& $password==$password) {
//     header('Location: login.php');

// }else{
//     echo'wrong email and pass'
// }
  }
// $connection=mysqli_connect('localhost','root','','dbhery');
// $sql=mysqli_query($connection,"INSERT INTO `student` (`Name`, `email`, `password`) VALUES ('$name', '$email', '$password')");
//   }else {
//     'record not found';
//   };
// $connection =mysqli_connect('localhost','root','','dbhery');
// $result=mysqli_query($connection,"SELECT * FROM `student`");

// while($coloum=mysqli_fetch_array($result)){
//     echo $coloum[0]."<br>";
//     echo $coloum[1] ."<br>";
//     echo $coloum[2] ."<br>";
// }
// if($_SERVER('REQUEST_METHOD')=='post'){
//     $name ->$_POST['name'];
//     $email->$_POST['email'];
//     $password->$_POST['password'];
//     echo'my name is '.$name.'email is'.$email .'valid';
// }
// ?>
</body>
</html>