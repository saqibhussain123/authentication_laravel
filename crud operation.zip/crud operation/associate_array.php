<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Associate array</title>
</head>
<body>
    <?php
echo'Associate array';
$arr=array('this ','what ','how');
echo'<br>';
// echo'<br>'. $arr[0];
// echo'<br>'. $arr[1];
// echo'<br>'. $arr[2];

foreach ($arr as $value) {
    echo $value . "<br>";  // Print each value followed by a line break
}
$color=array('saqib'=>'red','ali'=>'green','kashif'=>'blue',8=>'cool');
// echo $color['ali'];
// echo $color['kashif'];
// echo $color['saqib'];
// echo $color[8];
// Use foreach loop to print key-value pairs
foreach ($color as $key => $value) {
    echo "Key: $key, Value: $value<br>";  // Print key and value
}
    ?>
</body>
</html>