<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "crud_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Create
if (isset($_POST['create'])) {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $sql = "INSERT INTO records (name, age) VALUES ('$name', $age)";
    $conn->query($sql);
}

// Handle Update
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $sql = "UPDATE records SET name='$name', age=$age WHERE id=$id";
    $conn->query($sql);
}

// Handle Delete
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $sql = "DELETE FROM records WHERE id=$id";
    $conn->query($sql);
}

// Fetch Records
$records = $conn->query("SELECT * FROM records");
?>

