
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
</head>
<body>
    <div class="conatiner">
        <form action="conncrtion.php" method="post" >
          <label for="">Name</label>
          <input type="text" name="name" placeholder="enter your name here">
          <label for="">email</label>
          <input type="text" name="email" placeholder="email">
          <input type="submit" value="click here">
        </form>
    </div>
    <?php
   if ($_SERVER('REQUEST_METHOD')=='post'){
    $name ->$_POST['name'];
    $email->$_POST['email'];
    echo`name is $name and email is $email valid`;
   }

?>
</body>
</html>