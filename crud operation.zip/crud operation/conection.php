<?php
$servername="localhost";
$username="root";
$password="";
$database="dbhery";

$conn=mysqli_connect($servername,$username,$password,$database);
if(!$conn){
    die('connection are not connectionto db'.mysqli_connection_error());

}else{
    echo'connection are connected in database';
}

$sql ="SELECT * FROM `student` ";
$result=mysqli_query($conn,$sql);

$num =mysqli_num_rows($result);

echo"record found in database"

?>