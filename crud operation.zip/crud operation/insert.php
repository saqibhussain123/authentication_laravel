<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method="POST">
        Name <input type="text" name="name" placeholder="Enter your name here">
        Email <input type="text" name="email" placeholder="Enter your email here">
        password <input type="text" name="password" placeholder="Enter your password here">
        <input type="submit" value="click here" name="submit">
    </form>

    <?php

if (isset ($_POST ['submit'])) {
$name = $_POST ['name'];
$email = $_POST ['email'];
$password =$_POST ['password'];

echo "my name is ".$name ."<br>";
echo "my email is ".  $email ."<br>";
echo "my password is ".$password ."<br>";
    # code...


    $conn=mysqli_connect('localhost','root','','dbhery');
    $query=mysqli_query($conn,"INSERT INTO `student` (`Name`, `email`, `password`) VALUES ('$name', '$email', '$password')");
}else{
    echo"record not found";
}

$con=mysqli_connect('localhost','root','','dbhery');
$result=mysqli_query($con,"SELECT * FROM `student`
 ");
while ($col=mysqli_fetch_array($result)) {
    echo $col[0];
echo $col[1];
echo $col[2];
echo $col[3];
echo "<br>";

}
?>
<a href="view.php? value <?php $col[0] ?>" target="_blank">show</a>


</body>
</html> -->