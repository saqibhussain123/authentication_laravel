<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

 $matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];

// Accessing elements in a 2D array
echo $matrix[1][1];
echo'<br>';
// echo var_dump  ($matrix);
for ($i=0; $i <count($matrix) ; $i++) { 
    // echo var_dump($matrix[$i]);
    for ($j=0; $j <count($matrix[$i]) ; $j++) { 
        echo $matrix[$i][$j];
        echo'  ';
    }
    echo '<br>';
}
?>

</body>
</html>