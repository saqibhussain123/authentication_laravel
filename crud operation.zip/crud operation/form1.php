<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <form action="#" method="post">
            <label for="">Name</label>
            <input type="text" name="name" placeholder="enter your name">
            <label for="">email</label>
            <input type="email" name="email" placeholder="enter your email">
            <label for="">password</label>
            <input type="password" name="password" placeholder="enter your password">
       <input type="submit" value="click here" name="submit" >
        </form>
    </div>
    <?php

// if(isset($_POST['submit'])){
//   $name=$_POST=['name'];
//   $email=$_POST=['email'];
//   $password=$_POST['password'];

// echo "my name is". $name;  
// echo `my email is $email`;  
// echo `my password is $password`;

if (isset($_POST['submit'])) {
  // Correctly retrieve form data using $_POST
  $name = $_POST['name'];
  $email = $_POST['email'];
  $password = $_POST['password'];

  // Properly output the values
  echo "My name is " . $name . "<br>";
  echo "My email is " . $email . "<br>";
  echo "My password is " . $password . "<br>";
}







    // if(isset($_POST['submit'])){
    //   $name=$_POST['name'];
    //   $email =$_POST['email'];
    //   $password =$_POST['password'];
    //   echo `my name is $name and email is $email and password is $password`;
    // }
    
  // if($_SERVER('REQUEST_METHOD')=='post'){
  //   $name=$_POST['name'];
  //   $email=$_POST['email'];
  //   $password=$_POST['password'];
  //   echo`my name is $name and $email and $password `;
  // }
   
?>
</body>
</html>