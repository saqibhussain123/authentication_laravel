<?php
$id=$_GET['id'];

$conn=mysqli_connect('localhost','root','','dbhery');
$result=mysqli_query($conn,"SELECT * FROM `student` WHERE id=$id;");
?>