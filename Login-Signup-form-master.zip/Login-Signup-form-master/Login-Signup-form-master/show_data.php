$conn=mysqli_connect('localhost','root','','dbhery');
$result=mysqli_query($conn,"SELECT * FROM `student` ");
while($col=mysqli_fetch_array($result)){
    echo "id is".$col[0]."name is".$col[1]."email ".$col[2]."password".$col[3]."<br>"?>
 echo   <a href="update.php?id=<?php echo $col[0]?>">update</a>
    <?php

?>