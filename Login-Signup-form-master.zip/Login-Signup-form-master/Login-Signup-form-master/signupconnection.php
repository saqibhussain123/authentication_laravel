<?php
if (isset($_POST["submit"])) {
    $name  =$_POST['name'];
    $email  =$_POST['email'];
    $password  =$_POST['password'];
    echo'name'.$name.'email'.$email.'password'.$password;
echo'<br>';
    
$conn=mysqli_connect('localhost','root','','dbhery');
$query=mysqli_query($conn,"INSERT INTO `student`( `Name`, `email`, `password`) VALUES ('$name','$email','$password')");
if (!$query) {
    die("connection are not connected".mysqli_error($conn));

}else{
    echo "connecton are connected";
}




}
$conn=mysqli_connect('localhost','root','','dbhery');
$result=mysqli_query($conn,"SELECT * FROM `student` ");
while($col=mysqli_fetch_array($result)){
    echo "id is".$col[0]."name is".$col[1]."email ".$col[2]."password".$col[3]."<br>"
?>
   <a href="update.php?id=<?php echo $col[0]?>">update</a>
    <?php
}

?>
