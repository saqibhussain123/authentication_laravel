<?php
session_start();

echo "logouting you out . please wait ....";
session_destroy();
header("location:/welcome.php")
?>