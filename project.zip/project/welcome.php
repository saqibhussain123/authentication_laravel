<h1>welcome page </h1>
<!-- Nav tabs -->
<ul class="nav nav-tabs" id="navId">
<li class="nav-item">
        <a href="#" class="nav-link active">php</a>
        <a class="dropdown-item" href="login.php">login</a>
        <a class="dropdown-item" href="signup.php">signup</a>
        <a class="dropdown-item" href="#">welcome page</a>
        <a href="logout.php" class="nav-link">logout</a>
    </li>
   
  
</ul>

<!-- Tab panes -->
<div class="tab-content">
    <div class="tab-pane fade show active" id="tab1Id" role="tabpanel"></div>
    <div class="tab-pane fade" id="tab2Id" role="tabpanel"></div>
    <div class="tab-pane fade" id="tab3Id" role="tabpanel"></div>
    <div class="tab-pane fade" id="tab4Id" role="tabpanel"></div>
    <div class="tab-pane fade" id="tab5Id" role="tabpanel"></div>
</div>

<script>
    $('#navId a').click(e => {
        e.preventDefault();
        $(this).tab('show');
    });
</script>