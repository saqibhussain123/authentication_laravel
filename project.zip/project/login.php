<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method="post">
        Email <input type="text" name="email" id="">
        password <input type="text" name="password" id="">
        <input type="submit" value="click here" name="submit">
        <a href="signup.php">signup</a>
    </form>
    <?php

if (isset($_POST['submit'])) {
    $email=$_POST['email'];
    $password=$_POST['password'];
    
 $login =false;
 $showerror=false;
 
$conn=mysqli_connect('localhost','root','','dbhery');
$sql="SELECT * FROM `student` WHERE email =$email AND password=$password";
$result=mysqli_query($conn,$sql);
$num=mysqli_num_rows($result);
if ($num==1) {
    $login=true;
    echo"login successfully";
    session_start();
    $_SESSION['loggedin']=true;
    $_SESSION['email']=$email;
    header("location : welcome.php");
}else{
   echo $showerror="in valid pass and email";
}
}
?>
</body>
</html>