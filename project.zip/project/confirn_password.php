<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method="post">
        Name <input type="text" name="name">
        Email <input type="email" name="email">
        password<input type="password" name="password">
        confirm_password <input type="password" name="c_pass" >
        <input type="submit" value="click here" name="submit">
        <a href="login.php">login</a>
    </form>

    <?php

     if(isset($_POST['submit'])){
        $name=$_POST['name'];
        $email=$_POST['email'];
        $password=$_POST['password'];
        $c_pass=$_POST['c_pass'];
        echo$name;
        echo$email;
        echo $password;
         $exist=false;

         // check whether this username exists
         $existsql="SELECT * FROM 'student' WHERE name ='i'";
         $result=mysqli_query($conn,$existsql);





         if (($password==$c_pass)&& $exist==false) {
            # code...
            $conn=mysqli_connect("localhost","root","","dbhery");
            $query=mysqli_query($conn,"INSERT INTO `student`( `Name`, `email`, `password`) VALUES ('$name','$email','$password')");
         }else{
            echo'password donot match';
         }
         if (!$conn) {
            die("connection are not connected in database");
        }else {
            echo"connection are successfully";
        }
    
       
    
     }
   


?>
</body>
</html>